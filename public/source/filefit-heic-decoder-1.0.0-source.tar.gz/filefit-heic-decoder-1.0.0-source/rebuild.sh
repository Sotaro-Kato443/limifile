#!/bin/bash
# Real, executable rebuild driver for this package. Run this INSIDE the
# pinned Docker image (see BUILD.md) -- it needs emcc/em++/emcmake/emmake on
# PATH and does not install Emscripten itself.
#
# Usage:
#   ./rebuild.sh baseline
#   ./rebuild.sh modified-libheif  --marker your-marker-here
#   ./rebuild.sh modified-libde265 --marker your-marker-here
#
# There is no generic "--patch <any-path>" mode. modified-libheif and
# modified-libde265 each patch one specific, hardcoded file (libheif's or
# libde265's own version-string header) -- narrower than a prior version of
# this script, which accepted an arbitrary path under node_modules/ and was
# harder to review for safety.
#
# Uses ONLY this package's own jsquash/ tree and upstream/*.tar.gz archives.
# Never fetches anything over the network -- safe to run with no network
# access at all (e.g. `docker run --network=none`), as long as the image
# already has emcc/em++/cmake and (for baseline builds only, since this
# script itself never invokes apt) any OS packages the Makefile's own build
# step needs are already installed.
set -euo pipefail
cd "$(dirname "$0")"
PACKAGE_ROOT="$PWD"

MODE="baseline"
MARKER=""
while [ $# -gt 0 ]; do
  case "$1" in
    baseline|modified-libheif|modified-libde265)
      MODE="$1"
      shift
      ;;
    --marker)
      MARKER="$2"
      shift 2
      ;;
    *)
      echo "unknown argument: $1" >&2
      exit 1
      ;;
  esac
done

if [ "$MODE" != "baseline" ]; then
  if [ -z "$MARKER" ]; then
    echo "mode=$MODE requires --marker <string>" >&2
    exit 1
  fi
  # Marker text is embedded into a sed replacement below. Restrict it to a
  # safe character set up front so it can never be interpreted as sed
  # syntax (a "/", "&", or backslash in an unvalidated marker could alter
  # what sed actually replaces).
  case "$MARKER" in
    *[!A-Za-z0-9_-]*)
      echo "invalid --marker: only [A-Za-z0-9_-] characters are allowed: $MARKER" >&2
      exit 1
      ;;
  esac
fi

export CFLAGS="-Oz -flto"
export CXXFLAGS="$CFLAGS -std=c++17"
export LDFLAGS="$CFLAGS -s PTHREAD_POOL_SIZE=navigator.hardwareConcurrency -s FILESYSTEM=0 -s ALLOW_MEMORY_GROWTH=1 -s TEXTDECODER=0"

WORK_DIR="$(mktemp -d "${TMPDIR:-/tmp}/filefit-heic-rebuild-$MODE-XXXXXX")"
echo "Working directory: $WORK_DIR"
cp -R jsquash/packages/heic/codec "$WORK_DIR/codec"
mkdir -p "$WORK_DIR/codec/node_modules"
cp upstream/libheif-v1.19.7.tar.gz "$WORK_DIR/codec/node_modules/libheif.tar.gz"
cp upstream/libde265-v1.0.15.tar.gz "$WORK_DIR/codec/node_modules/libde265.tar.gz"

cd "$WORK_DIR/codec"

# jsquash/packages/heic/codec/dec/ ships a prebuilt reference heic_dec.js/
# heic_dec.wasm as part of jSquash's own committed tree (see README.md
# "This package is not source-only"). Delete both here, before the source
# build runs, so this rebuild can only succeed by actually regenerating them
# from heic_dec.cpp + the two upstream libraries below -- never by silently
# reusing or copying the pre-existing files.
rm -f dec/heic_dec.js dec/heic_dec.wasm

# Materialize source only (extracts the two archives we just placed --
# the Makefile's own targets for this only run if node_modules/libheif.tar.gz
# / node_modules/libde265.tar.gz already exist, which they now do, so this
# never reaches the Makefile's curl-based download rules).
emmake make node_modules/libheif/CMakeLists.txt node_modules/libde265/CMakeLists.txt

if [ "$MODE" != "baseline" ]; then
  case "$MODE" in
    modified-libheif)
      # Doubled libheif/libheif/... segment is not a typo -- see BUILD.md.
      TARGET="node_modules/libheif/libheif/api/libheif/heif_version.h.in"
      ALLOWED_ROOT="node_modules/libheif"
      PATCH_PATTERN='@PROJECT_VERSION_PATCH@"'
      ;;
    modified-libde265)
      # Same doubled-path reasoning as libheif, for the same structural
      # reason (libde265's release archive's own top level also contains a
      # libde265/ subdirectory) -- see BUILD.md.
      TARGET="node_modules/libde265/libde265/de265-version.h.in"
      ALLOWED_ROOT="node_modules/libde265"
      PATCH_PATTERN='@PACKAGE_VERSION@"'
      ;;
  esac

  if [ -L "$TARGET" ]; then
    echo "invalid patch target: is a symlink, refusing: $TARGET" >&2
    exit 1
  fi
  if [ ! -f "$TARGET" ]; then
    echo "patch target not found: $TARGET" >&2
    exit 1
  fi

  # Defense in depth: even though TARGET is now a hardcoded path (not
  # attacker-influenced), still confirm it resolves inside the extracted
  # tree it's supposed to belong to -- protects against a corrupted or
  # tampered upstream archive substituting a symlinked intermediate
  # directory to escape ALLOWED_ROOT.
  REAL_ROOT="$(cd "$ALLOWED_ROOT" && pwd -P)"
  REAL_TARGET_DIR="$(cd "$(dirname "$TARGET")" && pwd -P)"
  case "$REAL_TARGET_DIR" in
    "$REAL_ROOT"|"$REAL_ROOT"/*)
      ;;
    *)
      echo "invalid patch target: resolved path escapes $ALLOWED_ROOT: $REAL_TARGET_DIR" >&2
      exit 1
      ;;
  esac

  # Each mode only knows how to apply its own one specific string patch.
  # Refuse to proceed if the exact substitution pattern isn't present
  # exactly once (e.g. libheif's @PROJECT_VERSION_PATCH@ also appears,
  # without the trailing quote, in the unrelated LIBHEIF_NUMERIC_VERSION
  # line -- PATCH_PATTERN above includes the trailing quote specifically to
  # avoid matching that).
  MATCH_COUNT=$(grep -Fc "$PATCH_PATTERN" "$TARGET" || true)
  if [ "$MATCH_COUNT" -ne 1 ]; then
    echo "expected exactly 1 occurrence of $PATCH_PATTERN in $TARGET, found $MATCH_COUNT" >&2
    exit 1
  fi

  cp "$TARGET" "$TARGET.orig"
  case "$MODE" in
    modified-libheif)
      sed -i.bak "s/@PROJECT_VERSION_PATCH@\"/@PROJECT_VERSION_PATCH@-$MARKER\"/" "$TARGET"
      ;;
    modified-libde265)
      sed -i.bak "s/@PACKAGE_VERSION@\"/@PACKAGE_VERSION@-$MARKER\"/" "$TARGET"
      ;;
  esac
  rm -f "$TARGET.bak"
  echo "Patched $TARGET:"
  diff -u "$TARGET.orig" "$TARGET" || true
fi

emmake make -j"$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 2)"

mkdir -p "$PACKAGE_ROOT/out/$MODE"
cp dec/heic_dec.js dec/heic_dec.wasm "$PACKAGE_ROOT/out/$MODE/"
# heic_dec.js uses ESM syntax (import.meta.url); needs a sibling package.json
# declaring "type": "module" to load correctly outside the real npm package
# (whose own package.json normally provides this) -- see PR #12.
echo '{"type":"module"}' > "$PACKAGE_ROOT/out/$MODE/package.json"

echo ""
echo "Output: out/$MODE/heic_dec.wasm, out/$MODE/heic_dec.js"
if command -v sha256sum >/dev/null 2>&1; then
  sha256sum dec/heic_dec.wasm dec/heic_dec.js
else
  shasum -a 256 dec/heic_dec.wasm dec/heic_dec.js
fi
