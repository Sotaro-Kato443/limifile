# FileFit HEIC decoder — source and relink package

This source package is published based on FileFit's technical and license
self-review. It provides the source, build material, and documented
procedures used to rebuild and relink the HEIC decoder. **It has not been
reviewed by external legal counsel and is not legal advice or a guarantee
that every legal interpretation of LGPL requirements will agree with this
packaging decision.** It does not, by itself, establish that FileFit's LGPL
obligations are fully and conclusively satisfied. It is a technical
artifact: everything a developer needs to rebuild FileFit's HEIC decoder
WASM from source and relink it against a modified libheif or libde265,
produced and verified in [PR #12](https://github.com/Sotaro-Kato443/filefit/pull/12)
(a technical spike, also not legal advice or a compliance guarantee).

## What is in this package

- `upstream/` — the exact, unmodified upstream **archives** for libheif
  `v1.19.7` and libde265 `v1.0.15`, as fetched directly from GitHub, byte-
  for-byte identical to what `https://github.com/strukturag/{libheif,libde265}/archive/refs/tags/...`
  serves. These stay small enough (~2.1MB combined) to include as their
  original archives.
- `jsquash/` — jSquash commit `345892e0e48b428d47875a5b5678fbcf58f2880e`'s
  `packages/heic/` and `tools/` directories, **in full** (every file in
  both directories, not a hand-picked subset), extracted as a plain source
  tree rather than embedded as a raw archive. jSquash is a monorepo; that
  same commit also contains `packages/avif`, `packages/jpeg`,
  `packages/png`, `packages/webp`, `packages/jxl`, `packages/jxr`,
  `packages/oxipng`, `packages/qoi`, `packages/resize`, and
  `packages/gif` — separate codec packages that FileFit's HEIC build never
  reads, references, or links against (confirmed by `packages/heic/codec/Makefile`,
  included here, which only ever touches `packages/heic/` and `tools/`).
  **This is not a size-driven trim of HEIC-relevant source, and it is not a
  determination of LGPL's "Minimal Corresponding Source" scope** — those
  other packages are technically unconnected to the HEIC WASM build, full
  stop, independent of any licensing question. What counts as sufficient
  Corresponding Source for the HEIC decoder specifically remains a
  legal-interpretation question not conclusively resolved here (see
  "Remaining legal interpretation risks" below); this bullet is about codec
  packages that were never candidates for inclusion in the first place.
  jSquash's own full commit archive is a whole-monorepo snapshot (~25MB
  compressed, ~39MB uncompressed, of which the unrelated codec packages
  above are ~38MB); embedding it raw would have pushed this package over
  Cloudflare Pages' 25MiB single-asset limit for no benefit, since wrapping
  an already-compressed archive in another layer of gzip barely shrinks it
  further. `SOURCE-METADATA.json` records the exact commit and the full
  archive's own SHA-256 (the one this package's build script downloaded and
  verified before extracting `packages/heic/`/`tools/` from it), so the
  omission of the raw monorepo archive does not weaken the provenance claim
  for the files that matter here.
- `wrappers/` — the compiled JS wrapper/glue files exactly as published in
  `@discourse/heic@1.0.0` (the npm package FileFit
  actually depends on, pinned exactly — not a version range — in FileFit's
  own `package.json`), copied from the installed `node_modules` at build
  time.
- `application-code-candidates/` — see "Application code candidates" below.
- `licenses/` — reference license texts: canonical Apache-2.0, LGPL-3.0, and
  GPL-3.0 full text; Emscripten's own MIT/University of Illinois-NCSA
  `LICENSE`; musl's MIT `COPYRIGHT`; the LLVM Project's Apache-2.0-with-
  exceptions `LICENSE.TXT`; and this package's own scope-limited MIT grant
  for its support files (`mit-filefit-relink-support.txt`). See
  `LICENSE-MAP.md` for which license governs which file — this package does
  **not** use a single license for everything it contains.
- `LICENSE-MAP.md` — per-file/per-tree license table for this entire
  package. Start here if you need to know what license applies to a specific
  file.
- `SOURCE-METADATA.json`, `SHA256SUMS` — exact versions/commits/tags,
  compiler/linker/toolchain flags, and per-file hashes for everything in
  this package.
- `BUILD.md` — step-by-step rebuild instructions.
- `REPLACE-WASM.md` — how a rebuilt/relinked WASM maps onto what FileFit
  actually loads, and how far that technically goes.
- `Dockerfile`, `rebuild.sh`, `verify.mjs` — a runnable build/verify setup
  matching `BUILD.md`.

## This package is not source-only — jsquash/ includes a prebuilt reference WASM

`jsquash/packages/heic/codec/dec/heic_dec.wasm` and the sibling
`heic_dec.js` are part of jSquash's own committed source tree at the pinned
commit — jSquash's repository itself commits these as prebuilt/reference
build output, not source. This package embeds `packages/heic/` **in full**
(every file, not a hand-picked subset — see "What is in this package"
above), so this prebuilt pair comes along with it.

This is disclosed explicitly because it means the claim "this package
provides source" is not, by itself, a claim that every file in it is source
form. What matters for rebuilding is:

- `./rebuild.sh` **never reads** `jsquash/packages/heic/codec/dec/heic_dec.js`
  or `heic_dec.wasm` as a build input. It deletes both from its working
  copy immediately after copying `codec/`, before invoking the actual
  source build (see `rebuild.sh`'s `rm -f dec/heic_dec.js dec/heic_dec.wasm`
  step) — so a rebuild can only succeed by actually regenerating them from
  `heic_dec.cpp` + the two upstream libraries, never by silently reusing the
  pre-existing files. `verify-lgpl-heic-source-package.mjs`'s heavy rebuild
  workflow (in the FileFit repository) additionally checks this behavior.
- This prebuilt pair happens to be byte-identical to
  `@discourse/heic@1.0.0`'s published WASM/JS and to
  FileFit's Production build (`832bfb37148038257e56216d165cfae24a8afaa7cae8fc0ddb1ef4bf495612a9` /
  `646f18a658f6e0899c9620473ab556b2503dc1e39cbd36fe9dc30d43e0fdf6cc`), which this package's build script asserts and
  fails loudly if it ever stops being true. Its practical use is as a known-
  good reference to compare a fresh rebuild against — not as rebuild input.

## What was technically demonstrated (PR #12, run [30613638427](https://github.com/Sotaro-Kato443/filefit/actions/runs/30613638427))

- Rebuilding from these exact upstream sources reproduces FileFit's current
  Production `heic_dec.wasm`/`heic_dec.js` **byte-for-byte**
  (WASM SHA-256 `832bfb37148038257e56216d165cfae24a8afaa7cae8fc0ddb1ef4bf495612a9`, JS SHA-256 `646f18a658f6e0899c9620473ab556b2503dc1e39cbd36fe9dc30d43e0fdf6cc`).
- A harmless modification to libheif's source can be relinked into a working
  WASM, and the JS glue file needed no changes to use it (byte-identical
  before/after) — only `heic_dec.wasm` needs replacing. See "libde265
  relinking" below for the same demonstration against libde265's source.
- The rebuilt/relinked module instantiates, its `decode()` binding is
  callable, and it correctly rejects invalid input.

## What was NOT demonstrated

- **No real HEIC photo was decoded.** No HEIC test image with a clear
  redistribution license was available. Nothing here proves pixel-accurate
  decoding, HEVC/HEIF correctness, or functional equivalence with Production
  on real input.
- **No legal conclusion.** Whether this package satisfies LGPL's
  Corresponding Source requirements — including what counts as Corresponding
  Application Code, whether source-only (no object/bitcode) is sufficient,
  and whether this distribution method and retention period are adequate —
  remain open interpretation questions. See "Remaining legal interpretation
  risks" below.

## Remaining legal interpretation risks

This package is published based on FileFit's own technical and license
self-review, not external legal counsel. The following points are recorded
as risks/interpretation questions that are **not conclusively resolved**
by anything in this package — publishing this package does not mean
FileFit has determined an answer to any of them:

1. Is the Combined Work boundary correctly drawn at the single
   `heic_dec.wasm` (libheif + libde265 + jSquash's embind wrapper,
   statically linked), with FileFit's own JS/TS treated as calling code
   outside it?
2. Is Corresponding Application Code limited to jSquash's `heic_dec.cpp`,
   or does it extend to jSquash's `Makefile`/`pre.js`/build settings,
   and/or to FileFit's `heic-convert.worker.ts` (which only calls the
   published `decode()` through the WASM's public interface)?
3. Is source-only provision sufficient given `-flto` makes intermediate
   object files largely non-reusable, or is object/bitcode also required?
4. Does providing `packages/heic/` + `tools/` (not the full jSquash
   monorepo) fully satisfy "Minimal Corresponding Source" for the HEIC
   decoder, or is something more expected?
5. Is hosting this package ourselves (rather than only linking to
   discourse/jSquash, which has no tags/Releases) sufficient, given FileFit
   is the actual distributor to end users?
6. Is the source-retention policy in this README (available for as long as
   the corresponding WASM is served, version-named packages, no reliance on
   expiring CI artifacts) sufficient, or does LGPL require something more
   specific (e.g. a minimum fixed retention period)?
7. Is linking to this package from `/licenses` and the HEIC tool page an
   adequate offer of source, or does LGPL require something more active
   (e.g. a written offer)?
8. Does browser-delivered WASM (via Cloudflare Pages, no server-side
   processing) constitute "conveying" under LGPL terms the way this package
   assumes?
9. Are there reverse-engineering-restriction concerns specific to shipping a
   `-Oz -flto`-optimized, symbol-stripped WASM binary?
10. Are HEVC/H.265 patent questions genuinely separable from this LGPL
    analysis, or do they need to be addressed together? (Separately: the
    LLVM Exception's Apache-2.0 §4 waiver for libc++/libc++abi is a distinct
    question from LGPL compliance for libheif/libde265 — the two should not
    be conflated.)
11. Does the System Libraries exclusion (GPLv3 §1 / LGPLv3 §0) actually
    apply to Emscripten's runtime support, embind/emval, and musl for
    FileFit's specific distribution, such that their source need not be
    provided?
12. Is the narrow, package-scoped MIT grant on this package's own support
    files (`licenses/mit-filefit-relink-support.txt`) an adequate way to
    satisfy LGPLv3 §4(d)(0)'s requirement that Corresponding Application
    Code be provided "under terms that permit" recombination/relinking,
    without licensing FileFit's repository as a whole?

None of these are treated as blockers to publishing this package — FileFit
is publishing based on its own self-review while these interpretation
questions remain open, rather than withholding the package until an
external legal review resolves them. Absence of an answer here is not
itself evidence either way of legal sufficiency.

## What a WASM import does and does not prove

Several sections below, and `SOURCE-METADATA.json`, describe specific
functions that Production `heic_dec.wasm` **imports** — meaning it declares
that it needs `heic_dec.js` to supply a JavaScript implementation of that
function at instantiation time, not that the WASM implements that function
itself. An import is evidence of a *call site inside the WASM*, not evidence
of an *implementation inside the WASM*. Concretely, for Production
`heic_dec.wasm`:

- `__embind_register_bool`, `__embind_register_class`, `__emval_call`,
  `__emval_new_object`, and the rest of the `__embind_register_*`/`__emval_*`
  family are **imports** — the embind/emval *registration bookkeeping* is
  implemented in `heic_dec.js`'s generated Emscripten runtime support, not
  inside the WASM. (The C++ code that decides *what* to register —
  compiled from `heic_dec.cpp` and Emscripten's `embind`/`bind.cpp`
  headers — is compiled into the WASM as unnamed internal functions, but the
  registration mechanism itself runs in JS.)
- `__syscall_openat`, `__syscall_getdents64`, `__syscall_unlinkat`,
  `fd_read`, `fd_write`, `fd_seek`, `fd_close`, `environ_get`,
  `environ_sizes_get`, and `strftime_l` are **imports** implemented by musl-
  derived JS shims in `heic_dec.js`, not musl object code compiled into the
  WASM. Whether additional, higher-level musl libc logic is separately
  compiled *into* the WASM (as opposed to only these low-level primitives
  crossing to JS) is not confirmed either way from the stripped binary alone.
- `__cxa_throw` is an **import** — when the compiled code would throw a C++
  exception, it calls out to a JS-implemented throw path in `heic_dec.js`
  rather than running native WASM unwinding. This is evidence of a call
  site, not evidence that libc++abi's exception-unwinding machinery is
  compiled into the WASM.

By contrast, some libc++abi functions genuinely ARE compiled into and
**exported by** the WASM (`___cxa_is_pointer_type`, `___getTypeName`,
`__cxa_increment_exception_refcount`), and C++ RTTI `type_info`/
`std::string`-family mangled-name strings appear directly in the WASM's own
data — that is direct evidence of libc++abi object code compiled in, not
merely imported.

The practical consequence: **the final distributed artifact this package
documents is the `heic_dec.js` + `heic_dec.wasm` pair together**, not the
WASM in isolation. A description of "what's in the WASM" that ignores
`heic_dec.js`'s generated runtime support is incomplete. See
`SOURCE-METADATA.json`'s `emscriptenComponents` field for the full,
evidence-graded breakdown (confirmed-as-import vs. confirmed-as-internal vs.
unconfirmed) this section summarizes.

## Application code candidates

This package does not assert that Corresponding Application Code is limited
to `heic_dec.cpp`. What the technical record actually shows:

**Relationship to libheif**: `heic_dec.cpp` includes libheif's headers and
calls its C API directly via embind — the clearest single candidate. But
jSquash's `Makefile`, `pre.js`, and the compiler/linker settings recorded
in `SOURCE-METADATA.json` are also part of what determines the final
Combined Work, since they control how `heic_dec.cpp` is actually combined
with libheif into one WASM. FileFit's own
`heic-convert.worker.ts` (below) is not a build input for any of this — it
plays no role in compiling or linking the WASM.

**Relationship to libde265**: libheif uses libde265 as its HEVC decoder
plugin (`libheif/plugins/decoder_libde265.cc`), not `heic_dec.cpp`
directly. Recombining a modified libde265 into a working WASM therefore
depends on libheif's own source (the plugin glue code), not only on
libde265's source in isolation — which is why this package includes **both**
upstream archives (`upstream/libheif-*.tar.gz` and
`upstream/libde265-*.tar.gz`) rather than only libde265's. See "libde265
relinking" below for a demonstrated rebuild against a modified libde265,
analogous to the existing libheif demonstration.

**This is not a final determination of Application Code's legal scope.**
Both relationships above are recorded as technical facts about how the
Combined Work is actually built, not as a legal conclusion about what LGPL
requires FileFit to provide as Corresponding Application Code.

Conservatively, this package additionally includes FileFit's own
`heic-convert.worker.ts` as `application-code-candidates/heic-convert.worker.ts`:

- It is a **runtime integration example**, showing how FileFit's own code
  calls the published `decode()` function through the WASM's public
  interface (via `@discourse/heic/decode`).
- It is **not a WASM compilation or linking input** — nothing in
  `jsquash/packages/heic/codec/Makefile` reads, references, or links
  against it, and `rebuild.sh` never touches it.
- Including it here is **not a determination that it is legally required
  Corresponding Application Code** — that determination is not conclusively
  resolved here, same as for `heic_dec.cpp` (see "Remaining legal
  interpretation risks"). It is included as a conservative candidate for
  side-by-side review, not because its inclusion has been concluded to be
  necessary.
- The scope-limited MIT grant in `licenses/mit-filefit-relink-support.txt`
  applies only to **this package's copy** of the file
  (`application-code-candidates/heic-convert.worker.ts`, as distributed
  inside this specific `.tar.gz`). It does **not** change the license status
  of FileFit's own repository copy at
  `src/components/image-intake/heic-convert.worker.ts`, and does not apply
  to any other FileFit code, UI, or feature.

`application-code-candidates/heic_dec.cpp` is an **intentional, identical
copy** of `jsquash/packages/heic/codec/dec/heic_dec.cpp` — the same file
appears in both locations on purpose (one copy in its original upstream
location, one copy alongside the other Application Code candidate for easy
side-by-side review), not two independently-maintained versions.
`jsquash/packages/heic/codec/dec/heic_dec.cpp` is the source of truth; see
`SOURCE-METADATA.json`'s `applicationCodeCandidateIntegrity` field for both
files' SHA-256. Both this package's build script and
`scripts/verify-lgpl-heic-source-package.mjs` (in the FileFit repository)
fail if the two ever diverge.

## Emscripten and system runtime support

`heic_dec.js` (generated by Emscripten 3.1.57) contains Emscripten's own
runtime support code, plus the JS-side implementations of several functions
Production `heic_dec.wasm` imports (see "What a WASM import does and does
not prove" above). None of this is FileFit's or jSquash's own code:

- **Emscripten runtime, embind, and emval**: MIT / University of Illinois-
  NCSA (dual-licensed), copyright the Emscripten Authors. Reference text:
  `licenses/mit-emscripten.txt` (Emscripten 3.1.57's exact root `LICENSE`).
- **musl libc** (the syscall-primitive imports listed above): MIT, copyright
  the musl libc project. Reference text: `licenses/mit-musl.txt` (musl's own
  `COPYRIGHT` file from the exact Emscripten 3.1.57 tag).
- **libc++ / libc++abi** (confirmed compiled into Production `heic_dec.wasm`
  itself — see "What a WASM import does and does not prove" above):
  Apache License 2.0 WITH LLVM Exceptions, copyright the LLVM Project.
  compiler-rt / libunwind remain toolchain-default candidates whose presence
  in the final WASM is **not confirmed**. Reference text:
  `licenses/apache-2.0-llvm-exception.txt` (the LLVM Project's exact
  `LICENSE.TXT` from Emscripten 3.1.57's `system/lib/libcxx/`). That file's
  own LLVM Exception text states that Object-form embedding resulting from
  compiling this software does not require complying with License sections
  4(a), 4(b), and 4(d) — recorded here verbatim rather than summarized.

**This package does not include Emscripten's own source.** The reasoning —
not a legal conclusion, but the technical basis for why it isn't included —
is that GPLv3 §1's "System Libraries" definition excludes "a compiler used
to produce the work" and its normal packaging from Corresponding Source, and
LGPLv3 §0 separately excludes "System Libraries" from Corresponding
Application Code. Emscripten (the compiler/toolchain used to produce this
WASM) and its bundled runtime support are treated here as falling under that
exclusion. **Whether this exclusion is legally sufficient specifically for
FileFit's distribution is not asserted or determined by this package** — it
is recorded as the reasoning behind a packaging decision, not as a
compliance conclusion.

## libde265 relinking

In addition to the libheif relinking procedure demonstrated in PR #12 and
documented in `BUILD.md`/`REPLACE-WASM.md`, this package's `rebuild.sh`
supports an analogous `modified-libde265` mode: it patches libde265's own
version string (`libde265/libde265/de265-version.h.in`, the
`LIBDE265_VERSION` macro — the file libheif's plugin code reads via
`de265_get_version()`) with a marker, rebuilds, and the marker string
becomes visible in the resulting WASM via `strings`. See `BUILD.md` for the
full procedure and `REPLACE-WASM.md`/`SOURCE-METADATA.json` for the
verified results (baseline vs. modified-libheif vs. modified-libde265: WASM
SHA-256, size, import/export counts, and whether the JS glue stayed
byte-identical).

`rebuild.sh` no longer accepts an arbitrary `--patch <path>` argument for
this. Each of `modified-libheif` and `modified-libde265` patches one
specific, hardcoded, pre-reviewed file — there is no generic "patch any file
under `node_modules/`" mode.

## Package-specific file licensing

Most files in this package come from an upstream project (jSquash, libheif,
libde265, Emscripten) and carry that project's own license — see
`LICENSE-MAP.md`. The handful of files FileFit itself authored specifically
for this package (`README.md`, `BUILD.md`, `REPLACE-WASM.md`,
`LICENSE-MAP.md`, `Dockerfile`, `rebuild.sh`, `verify.mjs`,
`SOURCE-METADATA.json`, and this package's copy of
`application-code-candidates/heic-convert.worker.ts`) are licensed under a
narrow, package-scoped MIT grant —
`licenses/mit-filefit-relink-support.txt` — that applies **only to those
files as distributed inside this package**. It does not apply to FileFit's
repository as a whole, FileFit's UI, other FileFit image-processing
features, FileFit's site design, or (for the worker specifically) FileFit's
own repository copy of that file.

## File Fit's own code license status

FileFit's own source code (including its repository copy of
`heic-convert.worker.ts`, distinct from this package's copy above) does not
currently carry an explicit license header or declared license for its
application code, and this README does not add one on FileFit's behalf.

## Version and update history

This package corresponds to `@discourse/heic@1.0.0`
only, which FileFit's `package.json` now pins exactly (not as a `^` range)
specifically so this correspondence cannot silently drift. If FileFit's HEIC
dependency changes version in the future, this package must be regenerated
(see `scripts/build-lgpl-heic-source-package.mjs` in the FileFit repository,
which refuses to run if the installed version, lockfile entry, npm
integrity, or any wrapper/WASM file hash has drifted from what is pinned)
and re-published under a new version-numbered filename; it is not
automatically kept in sync.

## Source retention policy

- While FileFit serves a given Production `heic_dec.wasm` over the network,
  the corresponding version-named source package (this file, or its
  successor) is kept available at no charge, at the same origin as the WASM
  itself (currently: FileFit's own site, under `/source/`).
- When the `@discourse/heic` dependency version changes, a new,
  version-named package is published rather than overwriting this one in
  place.
- If an older Production WASM remains reachable by any means (e.g. a cached
  deployment, a prior release), the corresponding older source package is
  also kept available, not deleted once superseded.
- This repository's file at `public/source/filefit-heic-decoder-1.0.0-source.tar.gz`
  (served at `/source/filefit-heic-decoder-1.0.0-source.tar.gz`) is treated
  as the canonical distribution location. A GitHub Actions workflow artifact
  (which expires automatically) is not relied on as the primary or sole
  distribution point for this package.
- The package's filename, SHA-256, and size are recorded in
  `THIRD_PARTY_NOTICES.md`, `/licenses` on FileFit's site, and this
  package's own `SOURCE-METADATA.json`, and are updated together whenever
  the package is regenerated.

This describes an operating policy, not a legal conclusion about how long
retention is required, or about what form of access is legally sufficient —
see "Remaining legal interpretation risks" above.
