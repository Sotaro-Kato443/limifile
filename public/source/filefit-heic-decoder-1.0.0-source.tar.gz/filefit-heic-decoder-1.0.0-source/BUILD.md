# BUILD.md — rebuilding the HEIC decoder WASM from this package

These are the exact steps used in [PR #12](https://github.com/Sotaro-Kato443/filefit/pull/12)
and [PR #13](https://github.com/Sotaro-Kato443/filefit/pull/13)'s package-rebuild
verification workflow. **This package is the only source input** — `./rebuild.sh`
never fetches jSquash, libheif, or libde265 over the network; everything it
reads comes from `jsquash/` and `upstream/` inside this package.

That said, this is **not a claim of a fully air-gapped build environment**.
Getting to the point where you can run `rebuild.sh` still needs network
access for two things that are outside this package's control: pulling the
pinned Docker image, and installing the OS packages (`autoconf`, `libtool`,
`pkg-config`) the build needs via `apt-get`. The accurate description is:
**once a Docker environment with the required build dependencies is ready,
rebuilding needs no further network access to fetch upstream source.**

## Required environment

- Docker, able to run
  `emscripten/emsdk:3.1.57@sha256:8b7c9e9e95f3fb92b94876727a35235a8d2908c4d7e2ef2427f78366fd0b1130`
  (pinned by digest, not just tag; confirmed to resolve to a single-platform
  linux/amd64 manifest — see `SOURCE-METADATA.json`).
- Network access for the Docker image pull and `apt-get install` step below.
  No network access is needed after that.

## 1. Check Docker is available

```bash
docker version
```

## 2. Extract this package (if you have not already)

```bash
tar xzf filefit-heic-decoder-1.0.0-source.tar.gz
cd filefit-heic-decoder-1.0.0-source
sha256sum -c SHA256SUMS   # optional but recommended
```

## 3. Baseline build (unmodified sources)

Build a local image from this package's own `Dockerfile` (network required —
it pulls the pinned base image and `apt-get install`s `autoconf`/`libtool`/
`pkg-config` into that image), then run the actual source build from that
image with no network access at all:

```bash
docker build -t filefit-heic-source-build:local .

docker run --rm --network=none -v "$PWD":/work -w /work \
  filefit-heic-source-build:local \
  ./rebuild.sh baseline
```

(`docker build` is the network-connected step — it resolves the pinned
`emscripten/emsdk:3.1.57@sha256:8b7c9e9e95f3fb92b94876727a35235a8d2908c4d7e2ef2427f78366fd0b1130` base image and installs
build dependencies into a new local image layer. Once that image exists,
every `docker run --network=none ... filefit-heic-source-build:local`
against it has the dependencies already baked in, so the source build itself
never touches the network. This is the same two-phase structure —
network-connected image preparation, then network-isolated source build —
used by `verify-lgpl-heic-source-rebuild.yml` in the FileFit repository,
which builds an equivalent temporary verification image before running
`--network=none` against it. That temporary image is local/CI-only and is
never pushed to a public registry; the same applies to the
`filefit-heic-source-build:local` image you build here.)

`./rebuild.sh baseline` extracts `upstream/libheif-v1.19.7.tar.gz` and
`upstream/libde265-v1.0.15.tar.gz` locally (no network fetch), builds
both as static libraries with the same CMake flags as upstream's own
`Makefile` (`jsquash/packages/heic/codec/Makefile`, included in this
package: encoder disabled, x265/AOM/dav1d/rav1e/SvtEnc/Kvazaar/OpenJPEG/JPEG/
OpenH264/FFmpeg all explicitly `OFF`), then links
`jsquash/packages/heic/codec/dec/heic_dec.cpp` against them with:

```
-Oz -flto -std=c++17 --bind -s EXPORT_ES6=1 -s MODULARIZE=1 -s ENVIRONMENT=web,worker
```

## 4. Output location

```
out/baseline/heic_dec.wasm
out/baseline/heic_dec.js
```

## 5. Verify against Production

```bash
sha256sum out/baseline/heic_dec.wasm out/baseline/heic_dec.js
```

Expected (from `SOURCE-METADATA.json` / the successful PR #12 run):

```
832bfb37148038257e56216d165cfae24a8afaa7cae8fc0ddb1ef4bf495612a9  heic_dec.wasm
646f18a658f6e0899c9620473ab556b2503dc1e39cbd36fe9dc30d43e0fdf6cc  heic_dec.js
```

If these do not match, do not assume the rebuild is wrong before checking
toolchain/version drift — see PR #12's report for a discussion of what can
cause byte-level differences (LTO, timestamps, packaging).

## 6. Check import/export shape

```bash
node verify.mjs out/baseline/heic_dec.wasm
```

Prints import/export counts and custom-section presence (no dedicated tool
required; uses Node's built-in `WebAssembly` API only, matching PR #12's
approach). Expected for this exact build: 41 imports, 16 exports, no
`name`/`producers`/`sourceMappingURL` custom sections.

## 7. Relink against a modified library

`rebuild.sh` has three modes: `baseline` (step 3, above), `modified-libheif`,
and `modified-libde265`. There is no generic `--patch <any-path>` option —
each `modified-*` mode patches one specific, hardcoded, pre-reviewed file.
This is deliberate: a prior version of this script accepted an arbitrary
path under `node_modules/`, which was more general than necessary and
harder to review for safety. The two modes below cover the two upstream
libraries this package can currently demonstrate a relink against.

### 7a. Relink against a modified libheif

```bash
docker run --rm --network=none -v "$PWD":/work -w /work \
  filefit-heic-source-build:local \
  ./rebuild.sh modified-libheif --marker your-marker-here
```

Patches `node_modules/libheif/libheif/api/libheif/heif_version.h.in`'s
`LIBHEIF_VERSION` macro (the `@PROJECT_VERSION_PATCH@"` pattern), appending
`-<marker>`. The doubled `libheif/libheif/...` segment is not a typo: the
Makefile's `CODEC_DIR` (`node_modules/libheif`) is the extraction target
for the upstream libheif release archive, and that archive's own top level
(after the version-tag directory is stripped) already contains a
`libheif/` subdirectory before `api/libheif/heif_version.h.in`. PR #12's
own experiment patched this same file — see `REPLACE-WASM.md` for why it
was chosen.

### 7b. Relink against a modified libde265

```bash
docker run --rm --network=none -v "$PWD":/work -w /work \
  filefit-heic-source-build:local \
  ./rebuild.sh modified-libde265 --marker your-marker-here
```

Patches `node_modules/libde265/libde265/de265-version.h.in`'s
`LIBDE265_VERSION` macro (the `@PACKAGE_VERSION@"` pattern), appending
`-<marker>`. Same doubled-path reasoning as libheif above: libde265's
upstream release archive's own top level, after the version-tag directory is
stripped, already contains a `libde265/` subdirectory before
`libde265/de265-version.h.in`. This file is CMake-`configure_file()`'d into
`de265-version.h` at build time, and the resulting `LIBDE265_VERSION`
string is what `de265_get_version()` returns — a function libheif calls, so
the marker ends up reachable from the linked WASM the same way libheif's own
version string does.

For either mode, `--marker` takes the raw marker text with no leading
hyphen (`rebuild.sh` inserts the `-` separator itself) and is restricted to
`[A-Za-z0-9_-]` — anything else is rejected before it reaches `sed`.
`rebuild.sh modified-libheif`/`modified-libde265` extracts a fresh copy of
both libheif and libde265 from this package's own `upstream/` archives
(independent of any `baseline` run), verifies the exact substitution
pattern appears in the target file exactly once (refusing to proceed if it
is missing or ambiguous), and verifies the target path resolves inside the
expected extracted directory (rejecting a symlink escape, as defense in
depth even though the path itself is no longer attacker-influenced).

## 8. Confirm the modification is present

```bash
strings -n 6 out/modified-libheif/heic_dec.wasm | grep -i "your-marker-here"
strings -n 6 out/modified-libde265/heic_dec.wasm | grep -i "your-marker-here"
```

## 9. Invalid-input smoke test (NOT a real decode test)

```bash
node verify.mjs --smoke-test out/modified-libheif/heic_dec.js
node verify.mjs --smoke-test out/modified-libde265/heic_dec.js
```

This confirms the module instantiates in Node, its embind `decode()` binding
is callable, and it rejects a deliberately invalid buffer by returning
`null` without throwing — exactly what PR #12's own smoke test checked, no
more. **It does not decode a real HEIC image.**

## 10. What is still unverified after these steps

Real HEIC decode correctness on actual photo data. No HEIC fixture with a
clear redistribution license is included in this package or FileFit's
repository (see the "real HEIC fixture" note in PR #13). Before relying on a
rebuilt or relinked WASM for anything beyond this technical demonstration,
verify it against real, representative HEIC files under your own testing
process.
