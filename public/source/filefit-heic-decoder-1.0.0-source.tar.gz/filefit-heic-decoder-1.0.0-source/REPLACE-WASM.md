# REPLACE-WASM.md — swapping in a rebuilt/relinked WASM

This describes a **technically demonstrated procedure** (PR #12, run
[30613638427](https://github.com/Sotaro-Kato443/filefit/actions/runs/30613638427)),
not a legally-reviewed "sufficient" corresponding-source remedy. Whether this
satisfies LGPL's relinking requirements is not conclusively determined here
— see `README.md`'s "Remaining legal interpretation risks".

## Where the WASM lives today

- **Production npm package** (`@discourse/heic@1.0.0`):
  `node_modules/@discourse/heic/codec/dec/heic_dec.wasm` and the sibling
  `heic_dec.js` glue file.
- **FileFit's build**: Vite/Astro bundles `@discourse/heic/decode`
  (`src/components/image-intake/heic-convert.worker.ts` is the only FileFit
  code that imports it), which re-exports the same `decode.js` →
  `utils.js`/`codec/pre.js` → `codec/dec/heic_dec.js` chain shipped inside
  the npm package. FileFit does not fork, vendor, or modify any of these
  files (confirmed during the PR #12 audit).

## The key technical fact this package is built to support

PR #12's `verify` job compared the JS glue file produced by a baseline
rebuild against the JS glue file produced after relinking against a
source-modified libheif, and found them **byte-identical**. This package
additionally demonstrates the same result for a source-modified libde265
(`rebuild.sh modified-libde265` — see `BUILD.md`; results recorded in
`SOURCE-METADATA.json`). Concretely, in both cases: only `heic_dec.wasm`
changed when the library was modified; `heic_dec.js` did not need to change
at all.

This means the *technical* mechanics of "use a relinked library" reduce to
replacing one file:

```
node_modules/@discourse/heic/codec/dec/heic_dec.wasm   ← replace this file
node_modules/@discourse/heic/codec/dec/heic_dec.js      ← leave unchanged
```

(or the equivalent path inside whatever bundling step copies these files into
FileFit's build output — this package does not itself change FileFit's build
configuration.)

## How to verify a WASM you built is a valid drop-in

1. **SHA-256 the file** — compare against the value your own rebuild reports,
   and/or against Production's recorded value
   (`832bfb37148038257e56216d165cfae24a8afaa7cae8fc0ddb1ef4bf495612a9`) if you rebuilt *without* modification.
2. **Check the import/export shape matches** — run `verify.mjs` from this
   package against both the original and your rebuilt WASM. PR #12's
   baseline and modified builds both had 41 imports / 16 exports; a
   source-only change that doesn't alter the embind-exposed API surface
   should preserve this shape. A WASM with a different import/export shape
   is not a safe drop-in replacement — the JS glue's calling code assumes a
   specific ABI.
3. **Run the invalid-input smoke test** (`verify.mjs --smoke-test`) against
   the new WASM/JS pair together, to confirm the module still instantiates
   and the binding is still callable end-to-end.

## Local development check (not a Production change)

To try a locally-rebuilt WASM against FileFit's own dev server, replace the
file in a local `node_modules/@discourse/heic/codec/dec/heic_dec.wasm`
checkout and run `npm run dev`, then exercise the HEIC upload flow. **Do not
deploy this to Cloudflare Production** — that is a decision requiring its own
review, separate from this technical package.

## What this does not establish

- That this is the *only* correct way to satisfy relinking requirements.
- That WASM-only replacement is sufficient in every case — future libheif/
  libde265 changes could, in principle, alter the ABI in ways that also
  require JS glue changes; this package only reports what was true for the
  one modification tested in PR #12.
- Any conclusion about whether browser-delivered WASM constitutes "conveying"
  under LGPL terms, or whether this repository's public GitHub visibility is
  itself sufficient — both remain open interpretation questions, listed in
  `README.md`'s "Remaining legal interpretation risks".
