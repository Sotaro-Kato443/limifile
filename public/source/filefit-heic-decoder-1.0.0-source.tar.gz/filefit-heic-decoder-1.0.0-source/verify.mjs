#!/usr/bin/env node
// Standalone verification helper for this package. No dependencies beyond
// Node's built-ins (WebAssembly, crypto, fs) -- mirrors
// .github/workflows/lgpl-heic-rebuild/wasm-inspect.mjs and
// decode-smoke-test.mjs from PR #12, adapted to run outside that workflow.
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";
import path from "node:path";

const args = process.argv.slice(2);
const smokeTest = args.includes("--smoke-test");
const target = args.find((a) => !a.startsWith("--"));

if (!target) {
  console.error("usage: verify.mjs <heic_dec.wasm>");
  console.error("       verify.mjs --smoke-test <heic_dec.js>");
  process.exit(1);
}

if (smokeTest) {
  const jsPath = path.resolve(target);
  const wasmPath = jsPath.replace(/\.js$/, ".wasm");
  const moduleUrl = pathToFileURL(jsPath).href;
  const { default: createModule } = await import(moduleUrl);
  const wasmModule = await WebAssembly.compile(readFileSync(wasmPath));
  const mod = await createModule({
    noInitialRun: true,
    instantiateWasm(imports, successCallback) {
      const instance = new WebAssembly.Instance(wasmModule, imports);
      successCallback(instance);
      return instance.exports;
    },
  });
  if (typeof mod.decode !== "function") {
    console.log(JSON.stringify({ ok: false, reason: "decode() not exported" }, null, 2));
    process.exit(1);
  }
  const garbage = new Uint8Array([0, 1, 2, 3, 4, 5, 6, 7]).buffer;
  let result, threw = null;
  try {
    result = mod.decode(garbage);
  } catch (error) {
    threw = error instanceof Error ? error.message : String(error);
  }
  const ok = threw === null && (result === null || result === undefined);
  console.log(JSON.stringify({ ok, threw, resultType: typeof result }, null, 2));
  console.log(
    "\nNOTE: this only confirms module instantiation + embind decode() callability +",
    "invalid-input rejection. It does NOT decode a real HEIC image.",
  );
  process.exit(ok ? 0 : 1);
}

const buf = readFileSync(target);
const sha256 = createHash("sha256").update(buf).digest("hex");
const mod = await WebAssembly.compile(buf);
const imports = WebAssembly.Module.imports(mod);
const exports = WebAssembly.Module.exports(mod);
console.log(
  JSON.stringify(
    {
      path: target,
      size: buf.length,
      sha256,
      importCount: imports.length,
      exportCount: exports.length,
    },
    null,
    2,
  ),
);
